export const ROLE = Object.freeze({
    FREELANCER: "freelancer",
    CLIENT: "client",
  });
  