import React from 'react'
import TableView from "../components/atoms/contracts/TableView"
function Paypremium() {
    return (
        <div>
            <TableView/>
        </div>
    )
}

export default Paypremium
