export const deleteIconSVG = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="13.222"
    height="17"
    viewBox="0 0 13.222 17"
  >
    <g id="ic_mode_edit_24px" transform="translate(-48)">
      <path
        id="Icon_material-delete"
        data-name="Icon material-delete"
        d="M8.444,19.611A1.894,1.894,0,0,0,10.333,21.5h7.556a1.894,1.894,0,0,0,1.889-1.889V8.278H8.444ZM20.722,5.444H17.417L16.472,4.5H11.75l-.944.944H7.5V7.333H20.722Z"
        transform="translate(40.5 -4.5)"
        fill="#ff1616"
      />
    </g>
  </svg>
);
